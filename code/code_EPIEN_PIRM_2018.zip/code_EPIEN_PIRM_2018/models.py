import tensorflow as tf

def G1(input_image):

    with tf.variable_scope("generator"):

        W1 = weight_variable([5, 5, 3, 32], name="W1"); b1 = bias_variable([32], name="b1");
        c1 = tf.nn.relu(conv2d2(input_image, W1) + b1)


        W3 = weight_variable([3, 3, 32, 32], name="W3"); b3 = bias_variable([32], name="b3");
        c3 = tf.nn.relu(_instance_norm(conv2d(c1, W3) + b3))


        W5 = weight_variable([3, 3, 32, 64], name="W5"); b5 = bias_variable([64], name="b5");
        c5 = tf.nn.relu(_instance_norm(conv2d(c3, W5) + b5))
        
        ps = tf.depth_to_space(c5,2,name=None,data_format='NHWC')

        W9 = weight_variable([3, 3, 16, 64], name="W9"); b9 = bias_variable([64], name="b9");
        c9 = tf.nn.relu(_instance_norm(conv2d(ps, W9) + b9)) 
        
        ps = tf.depth_to_space(c9,2,name=None,data_format='NHWC')

        ps1 = tf.concat([input_image, ps], 3)

        W11 = weight_variable([3, 3, 19, 32], name="W11"); b11 = bias_variable([32], name="b11");
        c11 = tf.nn.relu(conv2d(ps1, W11) + b11)


        W12 = weight_variable([3, 3, 32, 3], name="W12"); b12 = bias_variable([3], name="b12");
        enhanced = tf.nn.tanh(conv2d(c11, W12) + b12) * 0.58 + 0.5
       

    return enhanced

def G2(input_image):

    with tf.variable_scope("generator"):

        W1 = weight_variable([5, 5, 3, 32], name="W1"); b1 = bias_variable([32], name="b1");
        c1 = tf.nn.relu(conv2d2(input_image, W1) + b1)


        W3 = weight_variable([3, 3, 32, 32], name="W3"); b3 = bias_variable([32], name="b3");
        c3 = tf.nn.relu(_instance_norm(conv2d(c1, W3) + b3))

        W5 = weight_variable([3, 3, 32, 64], name="W5"); b5 = bias_variable([64], name="b5");
        c5 = tf.nn.relu(_instance_norm(conv2d(c3, W5) + b5))

        
        ps = tf.depth_to_space(c5,2,name=None,data_format='NHWC')

        W9 = weight_variable([3, 3, 16, 64], name="W9"); b9 = bias_variable([64], name="b9");
        c9 = tf.nn.relu(_instance_norm(conv2d(ps, W9) + b9)) 


        ps = tf.depth_to_space(c9,2,name=None,data_format='NHWC')

        ps1 = tf.concat([input_image, ps], 3)


        W12 = weight_variable([1, 1, 19, 3], name="W12"); b12 = bias_variable([3], name="b12");
        enhanced = tf.nn.tanh(conv2d(ps1, W12) + b12) * 0.58 + 0.5
       

    return enhanced

def G3(input_image):

    with tf.variable_scope("generator"):

        W1 = weight_variable([5, 5, 3, 32], name="W1"); b1 = bias_variable([32], name="b1");
        c1 = tf.nn.relu(conv2d2(input_image, W1) + b1)


        W3 = weight_variable([3, 3, 32, 32], name="W3"); b3 = bias_variable([32], name="b3");
        c3 = tf.nn.relu(_instance_norm(conv2d(c1, W3) + b3))


        W5 = weight_variable([3, 3, 32, 32], name="W5"); b5 = bias_variable([32], name="b5");
        c5 = tf.nn.relu(_instance_norm(conv2d(c3, W5) + b5))

      
        ps = tf.depth_to_space(c5,2,name=None,data_format='NHWC')

        W9 = weight_variable([3, 3, 8, 32], name="W9"); b9 = bias_variable([32], name="b9");
        c9 = tf.nn.relu(_instance_norm(conv2d(ps, W9) + b9)) 
        
        ps = tf.depth_to_space(c9,2,name=None,data_format='NHWC')

        ps1 = tf.concat([input_image, ps], 3)

        W12 = weight_variable([1, 1, 11, 3], name="W12"); b12 = bias_variable([3], name="b12");
        enhanced = tf.nn.tanh(conv2d(ps1, W12) + b12) * 0.58 + 0.5
       

    return enhanced


def conv2d1(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 2, 2, 1], padding='SAME')

def vgg_19(image_):

    with tf.variable_scope("shared_model"):

        gray_image = tf.image.rgb_to_grayscale(image_)

        conv_00_w = tf.get_variable("conv_00_w", [3,3,1,64])
        conv_00_b = tf.get_variable("conv_00_b", [64])
        tensor = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(gray_image, conv_00_w, strides=[1,1,1,1], padding='SAME'), conv_00_b))

        for i in range(18):

            conv_w = tf.get_variable("conv_%02d_w" % (i+1), [3,3,64,64])
            conv_b = tf.get_variable("conv_%02d_b" % (i+1), [64])

            tensor = tf.nn.relu(tf.nn.bias_add(tf.nn.conv2d(tensor, conv_w, strides=[1,1,1,1], padding='SAME'), conv_b))

        conv_w = tf.get_variable("conv_20_w", [3,3,64,1])
        conv_b = tf.get_variable("conv_20_b", [1])

        tensor = tf.nn.bias_add(tf.nn.conv2d(tensor, conv_w, strides=[1,1,1,1], padding='SAME'), conv_b)
        tensor = tf.add(tensor, gray_image)

        tensor_colored = image_ - tf.image.grayscale_to_rgb(gray_image)
        tensor_colored += tf.image.grayscale_to_rgb(tensor)

    return tensor_colored


def weight_variable(shape, name):

    initial = tf.truncated_normal(shape, stddev=0.01)
    return tf.Variable(initial, name=name)

def bias_variable(shape, name):

    initial = tf.constant(0.01, shape=shape)
    return tf.Variable(initial, name=name)

def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

def conv2d2(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 4, 4, 1], padding='SAME')

def _instance_norm(net):

    batch, rows, cols, channels = [i.value for i in net.get_shape()]
    var_shape = [channels]

    mu, sigma_sq = tf.nn.moments(net, [1,2], keep_dims=True)
    shift = tf.Variable(tf.zeros(var_shape))
    scale = tf.Variable(tf.ones(var_shape))

    epsilon = 1e-3
    normalized = (net-mu)/(sigma_sq + epsilon)**(.5)

    return scale * normalized + shift

