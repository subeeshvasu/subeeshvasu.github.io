from __future__ import print_function
import tensorflow as tf
from scipy import misc
import numpy as np
import utils
import os

     
from models import G1 as test_model                  
model_location = "models_pretrained/G1_pretrained"
#from models import G2 as test_model                  
#model_location = "models_pretrained/G2_pretrained"
#from models import G3 as test_model                  
#model_location = "models_pretrained/G3_pretrained"

test = True

if __name__ == "__main__":

    print("\n-------------------------------------\n")

    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
    np.warnings.filterwarnings('ignore')

    print("Saving pre-trained model as .pb file")

    g = tf.Graph()
    with g.as_default(), tf.Session() as sess:

        image_ = tf.placeholder(tf.float32, shape=(1, None, None, 3), name="input")
        out_ = tf.identity(test_model(image_), name="output")

        saver = tf.train.Saver()
        saver.restore(sess, model_location)

        output_graph_def = tf.graph_util.convert_variables_to_constants(
            sess, g.as_graph_def(), "input,output".split(",")
        )

        tf.train.write_graph(output_graph_def, 'models_converted', 'model.pb', as_text=False)

    print("Model was successfully saved!")
    print("\n-------------------------------------\n")
    sess.close()

    if test:

        tf.reset_default_graph()
        config = None

        with tf.Session(config=config) as sess:

            print("\rLoading pre-trained model")

            with tf.gfile.FastGFile("models_converted/model.pb", 'rb') as f:

                graph_def = tf.GraphDef()
                graph_def.ParseFromString(f.read())
                tf.import_graph_def(graph_def, name='')

                x_ = sess.graph.get_tensor_by_name('input:0')
                out_ = sess.graph.get_tensor_by_name('output:0')

            y_ = tf.placeholder(tf.float32, [1, None, None, 3])

            output_crop_ = tf.clip_by_value(out_, 0.0, 1.0)
            target_crop_ = tf.clip_by_value(y_, 0.0, 1.0)

            psnr_ = tf.image.psnr(output_crop_, target_crop_, max_val=1.0)
            validation_images = os.listdir("dped/full_size_test_images/")
            num_val_images = len(validation_images)

            for j in range(num_val_images):
                
                image_phone = misc.imread("dped/full_size_test_images/" + validation_images[j])
                image_phone = np.reshape(image_phone, [1, image_phone.shape[0], image_phone.shape[1], 3]) / 255
                image_dslr = image_phone

                [psnr, enhanced] = sess.run([psnr_, out_], feed_dict={x_: image_phone, y_: image_phone})
                image_enhanced = np.reshape(enhanced, [image_dslr.shape[1], image_dslr.shape[2], 3])*255
                misc.imsave("visual_results/" + "enhanced_" + validation_images[j], image_enhanced)
            sess.close()

