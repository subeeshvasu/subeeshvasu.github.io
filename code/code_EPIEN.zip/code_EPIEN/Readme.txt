# Efficient Perceptual Image Enhancement Network (EPIEN) for Smartphones

Our code was developed on top of the official implementation of "DSLR-Quality Photos on Mobile Devices with Deep Convolutional Networks, Ignatov, Andrey and Kobyshev, Nikolay and Timofte, Radu and 
Vanhoey, Kenneth and Van Gool, Luc, ICCV 2017" (https://github.com/aiff22/DPED)

We have provided the test codes of 3 models of our final test-phase submissions in this folder.


#### Prerequisites

- [TensorFlow (>=1.8)](https://www.tensorflow.org/install/)
- Python (3.5+) packages: [scipy](https://pypi.org/project/scipy/), [numpy](https://pypi.org/project/numpy/), [psutil](https://pypi.org/project/psutil/)<br/><br/>


To test using our pre-trained models, run the following script:

- test_code.py

You need to modify two lines in the headers of the above scripts:

```bash
from <model_file> import <your_model> as test_model
model_location = "path/to/your/saved/pre-trained/model"
```

After running these scripts, they will:

1. save your model as ```model.pb``` file stored in ```models_pretrained/``` folder
2. save the resulting images in the ```visual_results/``` folder


To train the network:

1. Download the training code provided in "https://github.com/aiff22/DPED"
2. Change the generator module of model.py file to the one from G1/G2/G3 (network model of which can be found in models.py)
3. Add weighted form of MSE loss to the training code ("train_model.py" obtained from https://github.com/aiff22/DPED).
4. Run the training code with the parameter settings mentioned in our fact-sheet.

For queries, contact : Subeesh Vasu (subeeshvasu@gmail.com)
